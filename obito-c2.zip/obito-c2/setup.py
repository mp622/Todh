import os
import socket
import requests
import random
import getpass
import time
import sys
from Crypto import Random
from Crypto.Cipher import AES
import os
import os.path
from os import listdir
from os.path import isfile, join
import time

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

print("""
\x1b[38;5;160m        ░█████╗░██████╗░██╗████████╗░█████╗░  ░█████╗░██████╗░
\x1b[38;5;160m        ██╔══██╗██╔══██╗██║╚══██╔══╝██╔══██╗  ██╔══██╗╚════██╗
\x1b[38;5;160m        ██║░░██║██████╦╝██║░░░██║░░░██║░░██║  ██║░░╚═╝░░███╔═╝
\x1b[0m        ██║░░██║██╔══██╗██║░░░██║░░░██║░░██║  ██║░░██╗██╔══╝░░
\x1b[0m        ╚█████╔╝██████╦╝██║░░░██║░░░╚█████╔╝  ╚█████╔╝███████╗
\x1b[0m        ░╚════╝░╚═════╝░╚═╝░░░╚═╝░░░░╚════╝░  ░╚════╝░╚══════╝
""")

print("""[1] TO INSTALL""")
print("")
print("Jika Anda Ingin Run Tools Ini Install [1]")
print("Contoh ketik 1")
print("Jika Sudah Terinstall Ketik login")
rn = input(">>>  ")
if rn == '1':
    os.system("pip install cloudscraper")
    os.system("pip install socks")
    os.system("pip install pysocks")
    os.system("pip install colorama")
    os.system("pip install undetected_chromedriver")
    os.system("pip install httpx")
    os.system("apt-get install golang -y")
    os.system("apt-get install perl -y")
    os.system("apt-get install python3 -y")
    os.system("apt-get install nodejs -y")
    os.system("apt-get install npm -y")
    os.system("npm i request")
    os.system("npm i hcaptcha-solver")
    os.system("npm i randomstring")
    os.system("npm i cluster")
    os.system("npm i cloudflare-bypasser")
    os.system("npm i requests")
    os.system("npm i https-proxy-agent")
    os.system("npm i crypto-random-string")
    os.system("npm i events")
    os.system("npm i fs")
    os.system("npm i net")
    os.system("npm i url")
    os.system("ulimit -n 999999")
    os.system("chmod +x *")
    print("\33[0;32m[ √ ] TERINSTALL")
if rn == 'login':
	os.system("wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb")
	os.system("chmod +x *")
	print("\033[32mYour Welcome User To Obito Setup")
	print("\033[32mYour Username Is: DDOS")
	print("\033[32mYour Password Is: VIP")
	print("\033[32mYour Proxy Is user.txt")
	os.system("python3 OBITO.py")
else:
    print("?")

os.system("sudo apt-get install nodejs")
os.system("sudo apt-get install npm")
os.system("npm i events")
os.system("npm i fs")
os.system("npm i url")
os.system("npm i net")
os.system("npm i cloudscraper")
os.system("npm i request")
os.system("npm i randomstring")
os.system("npm i cluster")
os.system("npm i cloudflare-bypasser")
os.system("npm i hcaptcha-solver")
os.system("ulimit -n 999999")
os.system("chmod +x *")
os.system("sudo python3 c2.py")